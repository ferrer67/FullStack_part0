```mermaid

sequenceDiagram
participant navegador
participant servidor

navegador->>servidor: GET https://studies.cs.helsinki.fi/exampleapp/notes
Note right of servidor: servidor recibe peticion
servidor-->>navegador: Documento HTML "notes.html"
Note right of navegador: navegador recibe respuesta

navegador->>servidor: GET https://studies.cs.helsinki.fi/exampleapp/main.css
Note right of servidor: servidor recibe peticion
servidor-->>navegador: Documento CSS "main.css"
Note right of navegador: navegador recibe respuesta

navegador->>servidor: GET https://studies.cs.helsinki.fi/exampleapp/main.js
Note right of servidor: servidor recibe peticion
servidor-->>navegador: Documento JS "main.js"
Note right of navegador: navegador recibe respuesta

navegador->>servidor: GET https://studies.cs.helsinki.fi/exampleapp/data.json
Note right of servidor: servidor recibe peticion
servidor-->>navegador: Documento JSON "data.json"
Note right of navegador: navegador recibe respuesta

navegador->>servidor: POST https://studies.cs.helsinki.fi/exampleapp/new_note
Note right of servidor: servidor recibe peticion
servidor-->>navegador: GET https://studies.cs.helsinki.fi/exampleapp/notes
Note right of navegador: navegador recibe respuesta y recarga la página

navegador->>servidor: GET https://studies.cs.helsinki.fi/exampleapp/notes
Note right of servidor: servidor recibe peticion
servidor-->>navegador: Documento HTML "notes.html"
Note right of navegador: navegador recibe respuesta

navegador->>servidor: GET https://studies.cs.helsinki.fi/exampleapp/main.css
Note right of servidor: servidor recibe peticion
servidor-->>navegador: Documento CSS "main.css"
Note right of navegador: navegador recibe respuesta

navegador->>servidor: GET https://studies.cs.helsinki.fi/exampleapp/main.js
Note right of servidor: servidor recibe peticion
servidor-->>navegador: Documento JS "main.js"
Note right of navegador: navegador recibe respuesta

navegador->>servidor: GET https://studies.cs.helsinki.fi/exampleapp/data.json
Note right of servidor: servidor recibe peticion
servidor-->>navegador: Documento JSON "data.json" con la nueva nota
Note right of navegador: navegador recibe respuesta
    
```