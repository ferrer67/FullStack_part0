```mermaid

sequenceDiagram
participant navegador
participant usuario
participant servidor

navegador->>servidor: GET https://https://studies.cs.helsinki.fi/exampleapp/spa
Note right of servidor: servidor recibe peticion
servidor-->>navegador: Documento HTML "notes.html"
Note right of navegador: navegador recibe respuesta

navegador->>servidor: GET https://studies.cs.helsinki.fi/exampleapp/main.css
Note right of servidor: servidor recibe peticion
servidor-->>navegador: Documento CSS "main.css"
Note right of navegador: navegador recibe respuesta

navegador->>servidor: GET https://studies.cs.helsinki.fi/exampleapp/main.js
Note right of servidor: servidor recibe peticion
servidor-->>navegador: Documento JS "main.js"
Note right of navegador: navegador recibe respuesta

navegador->>servidor: GET https://studies.cs.helsinki.fi/exampleapp/data.json
Note right of servidor: servidor recibe peticion
servidor-->>navegador: Documento JSON "data.json"
Note right of navegador: navegador recibe respuesta

Note right of usuario: usuario entra en la version SPA
usuario->>navegador: introduce una nota en input
Note right of navegador:  navegador recibe evento
navegador->>servidor: POST https://studies.cs.helsinki.fi/exampleapp/new_note_spa
Note right of servidor: servidor recibe peticion i guarda la nota del usuario
    
```
<!-- El usuario accede en la version SPA en el momento en el que envia la nota por el formulario,  por lo que el navegador ya tiene la informacion necesaria para renderizar la aplicacion i simplemente se guarda la nota en formato json en el servidor -->